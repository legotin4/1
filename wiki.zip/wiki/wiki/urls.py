from django.conf.urls import patterns, include, url
from wiki.views import hello, thanks, enter, change, history, diff, commentsAll, newThread, addComment, check

from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'wiki.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),
    url(r'^hello/$', hello),
    url(r'^enter/$', enter),
	url(r'^thanks/$', thanks),
	url(r'^change/$', change),
	url(r'^history/$', history),
	url(r'^diff/$', diff),
    url(r'^comments/$', newThread),
    url(r'^comments_all/$', commentsAll),
    url(r'^addcomment/$', addComment),
    url(r'^check/$', check),
)
