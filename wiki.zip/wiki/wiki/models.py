#-*- coding:utf-8 -*-

from django.db import models 

class CardProfessions(models.Model):
	title = models.CharField(max_length=30)
	
	description = models.CharField(max_length=30)
	
	def __unicode__(self):
		return u'%s %s' % (self.title, self.description)

class Revolution(models.Model):
	title_id = models.ForeignKey('CardProfessions')
	
	title = models.CharField(max_length=30)

	description = models.CharField(max_length=30)
	
	def __unicode__(self):
		return u'%s %s %s' % (self.title_id, self.title, self.description)

class Comments(models.Model):
	text = models.TextField()
	nubmer = models.IntegerField(null=True)
	
	def __unicode__(self):
		return u'%s %s' % (self.text, self.number)

class Link(models.Model):
	ancestor = models.IntegerField(null=True)
	descendant = models.IntegerField(null=True)

	def __unicode__(self):
		return u'%s %s' % (self.ancestor, self.descendant)
