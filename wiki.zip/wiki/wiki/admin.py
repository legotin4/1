from django.contrib import admin
from wiki.models import CardProfessions, Revolution, Comments, Link

admin.site.register(CardProfessions)
admin.site.register(Revolution)
admin.site.register(Comments)
admin.site.register(Link)