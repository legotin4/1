# -*- coding:utf-8 -*- 
from django.http import HttpResponse
from django.template import RequestContext
from django.core.context_processors import csrf
from django.shortcuts import render_to_response
from django.http import HttpResponse, Http404, HttpResponseRedirect, JsonResponse
from wiki.forms import CardProfessionsForm
from wiki.models import CardProfessions, Revolution, Comments, Link
import difflib
import operator
import collections

def hello(request):
	return HttpResponse("hello")

def enter(request):
	c = {}
	if request.method == 'POST':
		form = CardProfessionsForm(request.POST)
		c.update(csrf(request))
		if form.is_valid():
			form.save()
			return HttpResponseRedirect('/thanks/')
	else:
		form = CardProfessionsForm()

	c = RequestContext(request, {'form': form})
	return render_to_response('enter_card.html', c)


def thanks(request):
	Card_list = CardProfessions.objects.all()
	c = RequestContext(request, {'Card_list': Card_list})
	
	return render_to_response('thanks.html', c)

def change(request):
	c = {}
	#ветка в рендеринг хтмл для дальнейшего изменения карточки
	if request.method == 'GET' and request.GET['q']:
		c.update(csrf(request))
		q = request.GET['q']
		global q
		message = u'Изменять запись под номером %s' % q
		from_id = CardProfessions.objects.filter(id=str(q))	
		c = RequestContext(request, {'message': message, "from_id": from_id})
		return render_to_response ('change.html', c)
		#ветка в изменение карточки в революции
	elif request.method == 'POST':
		c.update(csrf(request))
		form = request.POST
		if form is not None:
			title = request.POST['title']
			description = request.POST['description']
			revolution = Revolution() #добавили модели () и сука получилось 
			revolution.title_id = CardProfessions.objects.get(id=str(q)) #делаем это чтобы были связаны поля 
			revolution.title = title 
			revolution.description = description 
			print revolution.title, revolution.description
			revolution.save()
			return HttpResponseRedirect('/thanks/')
	else:
		return HttpResponse("всё пропало")

def history(request):
	c = {}
	if request.method == 'GET' and request.GET['h']:
		c.update(csrf(request))
		h = request.GET['h']
		get_id = CardProfessions.objects.get(id=str(h))
		get_history_all = Revolution.objects.select_related().filter(title_id = get_id.id)
		print get_history_all
						#Revolution.objects.filter(title_id__title = get_id.title) получет массив данных 
		c = RequestContext(request, {'get_id': get_id, 'get_history_all': get_history_all})
		return render_to_response ('history.html', c)

def diff(request):
					#получить из history.html get с id модели revolution подсмотреть как это сделано в thanks.html - сделать инпут и формэкшен к diff
	c = {}  
	if request.method == 'GET' and request.GET['i']:
		c.update(csrf(request))
		request_i = request.GET['i']
		diff_one = Revolution.objects.get(id=str(request_i))
		souz = (diff_one.title + ' ' + diff_one.description)
		title_id = diff_one.title_id
						#это id из таблицы card
		card_id = title_id.id
		revolution_title = diff_one.title
		revolution_description = diff_one.description
		global card_id
		global revolution_title
		global revolution_description
		title_id_line = u'%s' % title_id
		souz_line = u'%s' % souz
		result_diff = difflib.unified_diff(title_id_line.splitlines(True),souz_line.splitlines(True), lineterm='')
		c = RequestContext(request, {"souz": souz, "title_id": title_id, "result_diff": result_diff})
		return render_to_response('diff.html',  c)
					#пост в diff заменяет значение полей из революции в кард 
	elif request.method == 'POST':
		c.update(csrf(request))
		form = request.POST
		if form is not None:
			card_field = CardProfessions.objects.get(id=str(card_id));
			card_field.title = revolution_title
			card_field.description= revolution_description
			card_field.save()
			return HttpResponseRedirect('/thanks/')

def newThread(request):
	c = {}
	c.update(csrf(request))
	if request.method == 'GET':
		return render_to_response('comments.html', c)
	elif request.method == 'POST':
		message = request.POST['addcomment']
			#dataid = request.POST['dataid']
		if message is not None:
			comments = Comments()
			comments.text = message
			link = Link()
			comments.save()
			link.ancestor = comments.id 
				#link.descendant = dataid
			link.save()
			return HttpResponseRedirect('/comments_all/')	

def addComment(request):
	c = {}
	c.update(csrf(request))
	if request.method == 'GET' and request.GET:
		return HttpResponseRedirect('/comments/')
	elif request.method == 'POST' and request.is_ajax():
		message = request.POST.get('textarea')
		dataid = request.POST.get('data_id')
		if message != '':
			comments = Comments()
			comments.text = message
			link = Link()
			comments.save()
			comment_id = comments.id
			link.ancestor = dataid  
			link.descendant = comments.id
			link.save()
			return JsonResponse({"message": message, "descendant_id": comment_id, "ancestor_id": int(dataid)}, safe=False)
					#return HttpResponseRedirect('/comments_all/')
		else:
			return HttpResponse("Ответ был пуст.")

#def answerPost(request):
#	c = {}
#	c.update(csrf(request))
#	if request.method == 'POST' and request.is_ajax():


def commentsAll(request):
	c = {}
	c.update(csrf(request))
	link_all = Link.objects.all()
	filter_descendant = list(Link.objects.values('descendant'))
	#print filter_descendant
	list_sortig_ancestor = []
	for item in link_all:
		if item.ancestor not in list_sortig_ancestor:
			list_sortig_ancestor.append(item.ancestor)
	#делаем копию, в которую будем складывать всё
	list_comment_id = list_sortig_ancestor[:]
	#print list_sortig_ancestor
	new_link_all = []
	for item in link_all:
		new_link_all.append('{0}'.format(item.ancestor)) 
	
	#делаем из строк числа для того чтобы потом узнать сколько раз число входит "в"
	number_list_ancestor = []
	for item in new_link_all:
		if item == 'None':
			break
		else: number_list_ancestor.append(int(item))
	list_item_descendant_for = []
	clearx = []
	for itemsort in list_sortig_ancestor:
		length_descendand = number_list_ancestor.count(itemsort) #узнали длину cсколько раз входит
		#print u'сколько раз предок', length_descendand
		for itemlink in link_all:
			if (itemlink.ancestor == itemsort): 
				list_item_descendant_for.append(itemlink.descendant) #добивили в массив потомков
				#print itemlink.descendant
				#print 'list_item_descendant_for', list_item_descendant_for
				if (length_descendand == len(list_item_descendant_for)): #если длины массивов помоквов и количество эл. в линкалл совпадет
					#print u'равно'
					i = list_comment_id.index(itemsort)
					i = i + 1
					list_comment_id.insert(i, list_item_descendant_for) #list_comment_id[i:i] = list_item_descendant_for
					list_item_descendant_for = clearx[:]
			elif itemlink.ancestor is not itemsort:
				continue
			
	#print list_sortig_ancestor
	print list_comment_id

	new_list_comment = []
	for item in list_sortig_ancestor:
		if item not in new_list_comment:
			new_list_comment.append(item)
		for i in link_all:
			if i.ancestor == item:
				if i.descendant not in new_list_comment:
					index = new_list_comment.index(item)
					index = index + 1
					new_list_comment.insert(index, i.descendant)
	
	
	
	while new_list_comment.count(None) != 0:
		 new_list_comment.remove(None)

	
	
	list_link_all = []
	for i in link_all:
		if i.descendant == None:
			i.descendant = 0
		new = [i.ancestor,i.descendant]
		list(new)
		list_link_all.append(new)
		
	#print list_link_all
	print new_list_comment


	all_comments = Comments.objects.all()
	
	v = RequestContext(request, {'all_comments': all_comments, 'new_list_comment': new_list_comment, 'list_link_all': list_link_all })
	return render_to_response('comments_all.html', v)

def check(request):
	c = {}
	c.update(csrf(request))
	v = RequestContext(request, {})
	return render_to_response('check.html', v)

