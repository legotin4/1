$( document ).ready(function() {
    console.log( "ready!" );
    //console.log(list_link.length);
    //console.log(list_link);
    //console.log(list_link[1]);
    /*формат() как в питоне заменяет %s значениемя по очереди*/
    String.prototype.format = function() {
    var newStr = this, i = 0;
    while (/%s/.test(newStr))
        newStr = newStr.replace("%s", arguments[i++])

    return newStr;
   }
    var csrftoken = $.cookie('csrftoken');

  //делает дерево комментов
  $(".comment").each(function(indx, element){
    //console.log($(element).attr('data-id'));
    for (var i = 0; i < list_link.length; i++){
      //console.log(list_link[i][1]);
      if($(element).attr('data-id') == list_link[i][1]){
        //console.log('kyky')
        if((list_link[i][1]) == 0){
          break
         }
         //если коммент идет непосредственно за свои предком узнать его отступ прибавить отступ и + 10
        if($(element).parent().prev().children('p').attr('data-id') == list_link[i][0]){
          margin = $(element).parent().prev().css("margin-left") 
          margin = parseInt(margin, 10)
          margin = margin + 10
          $(element).parent().css("margin-left", "%spx".format(margin))
            //console.log('идет')
         }//иначе найти его в дереве и посмотреть сколько у него отступ и прибавить отступ и + 10
          else{
            margin = $('[data-id = %s]'.format(list_link[i][0])).parent().css("margin-left")
            margin = parseInt(margin, 10)
            //console.log(margin)
            margin = margin + 10
            $(element).parent().css("margin-left", "%spx".format(margin))
         }  
          
        //
      }

  }
    


  });  
  
  //ответ на пост 
  $('.answer_post').click(function(event){
    
    value_before = "<div><span class='x_post_textarea'>X</span><br/><textarea class='post_textarea'></textarea><br/>\
                    <span class='post_textarea_click'>Ответить</span></div>"

    if($(event.target).prev().children().is('textarea') == false){
      $(event.target).before(value_before)
    }
    console.log($(event.target).parent().children())
    $(this).hide();
    $('.post_textarea_click').click(function(event){
      console.log('отправить')
      var value_textarea = $(event.target).parent().find('textarea').val();
      console.log(value_textarea);
      var data_id = 0
      $.post(
        "/addcomment/",
        {
          "textarea" : value_textarea,
          "csrfmiddlewaretoken" : csrftoken,
          "data_id" : data_id
        },
        answer
        );
      function answer(data){
          console.log(data.descendant_id);
          console.log(data);
          $(".comment").each(function(index, element){
            if($(element).attr('data-id') == data.ancestor_id){
              margin = $(element).parent().css("margin-left");
              margin = parseInt(margin, 10)
              margin = margin + 10
              $(element).parent().after(
                                '<div style="margin-left: %spx;">\
                                <p class="comment" data-id="%s">%s</p>\
                                <span class="comment_add">Ответить</span>\
                                </div>'.format(margin, data.descendant_id, data.message)
                              )
              console.log('равен');
            }
          });
        }

      $(event.target).parent().parent().find('.answer_post').show()
      $(event.target).parent().remove();
    })
    $('.x_post_textarea').click(function(event){
      
      $(event.target).parent().parent().find('.answer_post').show()
      $(event.target).parent().remove();
      
    })
  })

  

//ответ на коммент
//$('.comment_add').click(function(event)
  $('.comments_divs').on('click', '.comment_add', function(event){
      var data_id = $(event.target).prev().attr("data-id");

      /*добавить форму отправки по клику на ответить
      value_after = "<form id='text' action='/addcomment/' method='post'>\
           <textarea class='add_textarea' name='addcomment' cols='40' form='text' autofocus></textarea>\
           <input type='hidden' name='dataid' value='%s'>\
           <input type='hidden' name='csrfmiddlewaretoken' value='%s'><br/>\
           <input class='add_form_submit' value='Отправить' type='submit'>\
           </form>".format(data_id, csrftoken);*/

      value_after = "<div class='add_form_div'><span class='x'>X</span><br/><textarea class='add_textarea'></textarea><br/>\
      <span class='submit'>Ответить</span></div>\
      "

      if($(event.target).parent().children().children().is('textarea') == false){
          $(event.target).after(value_after)
      }  
    /*$('.submit').on('click', function(){
          console.log('faeaefaef');
      });*/

    //hide 
    $(this).hide()

    //ответить после заполнения текстарии
    $('.submit').click(function(){
       //console.log()
       $(event.target).parent().parent().find('.comment_add').show();
       var value_textarea = $(event.target).parent().find('textarea').val();
       //it is ajax
       $.post(
        "/addcomment/",
        {
          "textarea" : value_textarea,
          "csrfmiddlewaretoken" : csrftoken,
          "data_id" : data_id
        },
        answer
        );
       $(event.target).parent().find('.add_form_div').remove()
        //функция добавляет пришедшее от сервера
        function answer(data){
          console.log(data.descendant_id);
          console.log(data);
          $(".comment").each(function(index, element){
            if($(element).attr('data-id') == data.ancestor_id){
              margin = $(element).parent().css("margin-left");
              margin = parseInt(margin, 10)
              margin = margin + 10
              $(element).parent().after(
                                '<div style="margin-left: %spx;">\
                                <p class="comment" data-id="%s">%s</p>\
                                <span class="comment_add">Ответить</span>\
                                </div>'.format(margin, data.descendant_id, data.message)
                              )
              console.log('равен');
            }
          });
        }

    })
    //крестик, закрытие текстаирии
    $('.x').click(function(event){
      
      $(event.target).parent().parent().find('.comment_add').show();
      $(event.target).parent().remove();
      
    })

  });
  
  $('.plus').one('click', function(event){
    console.log('plus');
    console.log($(event.target).parent().find('.number').text())
    var number = $(event.target).parent().find('.number').text()
    number = parseInt(number, 10)
    number = number + 1
    $(event.target).parent().find('.number').text('%s'.format(number))
    console.log(number)
  });
  $('.minus').one('click', function(event){
    console.log('minus');
    console.log($(event.target).parent().find('.number').text())
    var number = $(event.target).parent().find('.number').text()
    number = parseInt(number, 10)
    number = number - 1
    $(event.target).parent().find('.number').text('%s'.format(number))
    console.log(number)
  });

});


/*function submit(a){
     console.log(a)
     
     onclick='submit(%s);'
     .format(data_id);
  };*/

