from django.forms import ModelForm
from wiki.models import CardProfessions, Revolution

class CardProfessionsForm(ModelForm):
	class Meta:
		model = CardProfessions
		fields = ['title', 'description']


